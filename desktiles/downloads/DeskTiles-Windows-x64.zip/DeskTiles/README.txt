桌面拼格 DeskTiles — Windows x64 免安裝版

1. 先完整解壓縮 ZIP，再雙擊 DeskTiles.exe。
2. 適用 Windows 10／11 x64；不需安裝 Python、.NET 或 Visual Studio。
3. 在左側選擇形狀，按「新增圖形」；右側編輯內容後按套用。
4. 右上角「配置 JSON…」可匯出含圖片的備份或匯入範例配置。
5. 關閉控制視窗後，桌面圖形仍會繼續顯示；雙擊圖形可開啟控制視窗。
6. 要結束程式，從圖形右鍵或系統匣選「儲存並結束桌面拼格」。

版面預設儲存於 %LOCALAPPDATA%\HexDesk，沿用舊版本位置。
若已有程式使用相同資料目錄，會帶回既有視窗。要換新版，請先結束舊版。
完整操作說明請看「使用說明.md」。Linux 版尚未開發。

English: Extract the ZIP and run DeskTiles.exe. Choose English from the language selector in the upper-right corner. Your choice is remembered. Read UserGuide.en.md for instructions. Save and exit the old version before updating. No Python, .NET or development tools are required.
